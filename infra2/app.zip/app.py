
from fastapi import FastAPI
import mangum


app = FastAPI()
@app.get("/hello")
def main():
    return "Hello"

@app.get("/")
def main():
    return "Hello"


handler = mangum.Mangum(app)
